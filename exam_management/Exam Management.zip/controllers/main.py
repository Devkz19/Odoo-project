from odoo import http
from odoo.http import request
from odoo.exceptions import ValidationError, AccessDenied
import logging

_logger = logging.getLogger(__name__)

class StudentPortalController(http.Controller):

    def _odoo18_authenticate(self, email, password):
        """
        Odoo 18 specific authentication method
        """
        try:
            # Get current database name properly
            db_name = request.env.cr.dbname
            
            # Method 1: Use Odoo 18 session authenticate
            uid = request.session.authenticate(email, password)
            if uid:
                _logger.info(f"Authentication successful for user: {email}")
                return True
                
        except Exception as e:
            _logger.warning(f"Session authenticate failed: {e}")
            
            # Method 2: Manual authentication for Odoo 18
            try:
                # Find user
                user = request.env['res.users'].sudo().search([
                    ('login', '=', email),
                    ('active', '=', True)
                ], limit=1)
                
                if not user:
                    _logger.warning(f"User not found: {email}")
                    return False
                
                # Verify credentials
                user.sudo().check_credentials(password)
                
                # Manually setup session (Odoo 18 way)
                request.session.uid = user.id
                request.session.login = email
                request.session.session_token = user._compute_session_token(request.session.sid)
                request.session.context = user.context_get()
                
                _logger.info(f"Manual authentication successful for: {email}")
                return True
                
            except AccessDenied:
                _logger.warning(f"Invalid credentials for: {email}")
                return False
            except Exception as e:
                _logger.error(f"Manual authentication error: {e}")
                return False
        
        return False

    # Student Registration Page
    @http.route('/student/register', type='http', auth='public', website=True)
    def student_registration_form(self, **kw):
        exams = request.env['exam.planning'].sudo().search([])
        return request.render('exam_management.student_registration_template', {
            'exams': exams
        })

    @http.route('/student/register/submit', type='http', auth='public', website=True, methods=['POST'], csrf=True)
    def student_registration_submit(self, **post):
        name = post.get('name')
        email = post.get('email')
        phone = post.get('phone')
        password = post.get('password')
        course = post.get('course')
        semester = post.get('class_semester')

        exams = request.env['exam.planning'].sudo().search([])

        # Basic Validation
        if not all([name, email, phone, password, course, semester]):
            return request.render('exam_management.student_registration_template', {
                'error': 'All fields are required.',
                'exams': exams
            })

        # Check if user already exists
        existing_user = request.env['res.users'].sudo().search([('login', '=', email)], limit=1)
        if existing_user:
            return request.render('exam_management.student_registration_template', {
                'error': 'This email is already registered. Please login instead.',
                'exams': exams
            })

        try:
            # Create user with portal access
            portal_group = request.env.ref('base.group_portal')
            user = request.env['res.users'].sudo().create({
                'name': name,
                'login': email,
                'email': email,
                'password': password,  
                'groups_id': [(6, 0, [portal_group.id])]
            })

            # Create Student Profile
            student = request.env['student.registration'].sudo().create({
                'student_name': name,
                'email': email,
                'phone': phone,
                'course': course,
                'class_semester': semester,
                'status': 'assigned',
                'user_id': user.id,
            })

            # Commit the transaction to ensure user is created
            request.env.cr.commit()
            
            # Auto-login new student
            if self._odoo18_authenticate(email, password):
                return request.redirect('/student/profile')
            else:
                # Auto-login failed, redirect to login page
                return request.redirect('/web/login')

        except ValidationError as ve:
            return request.render('exam_management.student_registration_template', {
                'error': str(ve),
                'exams': exams
            })
        except Exception as e:
            _logger.error(f"Registration error: {e}")
            return request.render('exam_management.student_registration_template', {
                'error': 'Registration failed. Please try again.',
                'exams': exams
            })

    # Student Profile Page
    @http.route(['/student/profile'], type='http', auth='user', website=True)
    def student_profile(self, **kwargs):
        student = request.env['student.registration'].sudo().search([
            ('user_id', '=', request.env.user.id)
        ], limit=1)

        if not student:
            return request.render('exam_management.portal_no_student')

        return request.render('exam_management.student_profile_template', {
            'student': student
        })

    # Student Login
    @http.route('/student/login', type='http', auth='public', website=True)
    def student_login_form(self, **kw):
        message = kw.get('message')
        context = {}
        
        if message == 'please_login':
            context['info'] = 'Registration successful! Please login with your credentials.'
            
        return request.render('exam_management.student_login_template', context)

    @http.route(['/student/login/submit'], type='http', auth='public', website=True, methods=['POST'])
    def student_login_submit(self, **post):
        email = post.get('email')
        password = post.get('password')

        if not email or not password:
            return request.render('exam_management.student_login_template', {
                'error': 'Email and password are required'
            })

        # Use Odoo 18 authentication
        if self._odoo18_authenticate(email, password):
            return request.redirect('/student/profile')

        return request.render('exam_management.student_login_template', {
            'error': 'Invalid Email ID or Password'
        })

    # Logout
    @http.route('/student/logout', type='http', auth='user', website=True)
    def student_logout(self):
        request.session.logout(keep_db=True)
        return request.redirect('/student/login')

